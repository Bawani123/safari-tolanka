-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2020 at 03:23 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `useraccountnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_tab`
--

CREATE TABLE `contact_us_tab` (
  `ID` int(50) NOT NULL,
  `FULL_NAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `CONACT_NO` varchar(60) NOT NULL,
  `COUNTRY` varchar(60) NOT NULL,
  `SUBJECT_TITLE` varchar(100) NOT NULL,
  `MESSAGE` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_us_tab`
--

INSERT INTO `contact_us_tab` (`ID`, `FULL_NAME`, `EMAIL`, `CONACT_NO`, `COUNTRY`, `SUBJECT_TITLE`, `MESSAGE`) VALUES
(1, 'Ann Jenifer', 'annjenifer22@gmail.com', '96446575937', '', 'Requesting more details', 'please send to my email about more details wild life and jeep tour. Thank you'),
(2, 'Tom Riddle', 'tomriddle909@gmail.com', '9339497899', '', 'Get to know about offers', 'Can you send me your new offers and discounts'),
(3, 'Hermain Grenger', 'herminegrenger22@gmail.com', '933949789', '', 'Get to know about guide contacts', 'Can you send me my tour guide contact number.'),
(4, 'Jenny Whesly', 'jenywhesly55@gmail.com', '9339495858', '', 'Changing the Tour package', 'Is it possible that i can change the package to new one. I will land tomorrow.');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `firstname`, `lastname`, `email`, `phonenumber`, `password`) VALUES
('', '', '', '', '', ''),
('', 'Madavi', 'Shanika', 'madavi3@gmail.com', '098765432', 'Madavi#12345'),
('', 'Wasuni', 'Shashikala', 'wasu99@gmail.com', '087654321', 'Wasuni567'),
('', 'Jiny', 'jenifer', 'jiny45@gmail.com', '+76098765432', 'you12345'),
('', 'Mily', 'Ameena', 'Mily0@gmail.com', '+87098123456', 'mily4567'),
('', 'Karan', 'Guptha', 'karan89@gmail.com', '+9834579745', 'karanGuptha88'),
('', 'John', 'Kristin', 'john2@gmail.com', '+986431468', 'john9988'),
('', 'Amritha', 'Jim', 'jim02@gmail.com', '+70663743873', 'jim66@99'),
('', 'nivee', 'smith', 'nivee@gmail.com', '0981342658', 'smith0077'),
('', 'Vihari', 'Jonson', 'jonson@gmail.com', '+76098765432', 'jonson234'),
('', 'Bawani', 'Rupasinghe', 'brupasinghe3@gmail.com', '0975326890', 'Colombo10'),
('', 'Tom', 'Riddle', 'tomriddle55@gmail.com', '+9854324627484', 'tom123'),
('', 'Drako', 'Malfoi', 'drako4@gmail.com', '09845783822', 'drako55'),
('', 'Kamal', 'Withanage', 'kamal4@gmail.com', '9754235789', 'Kadawatha2');

-- --------------------------------------------------------

--
-- Table structure for table `joininformation`
--

CREATE TABLE `joininformation` (
  `id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `contactnumber` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `NIC` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `service` varchar(100) NOT NULL,
  `company` varchar(50) NOT NULL,
  `caddress` varchar(100) NOT NULL,
  `skills` varchar(100) NOT NULL,
  `experience` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `joininformation`
--

INSERT INTO `joininformation` (`id`, `firstname`, `lastname`, `email`, `contactnumber`, `age`, `gender`, `NIC`, `address`, `service`, `company`, `caddress`, `skills`, `experience`, `password`) VALUES
(1, 'Kavindu', 'Reshan', 'kavindu67@gmail.com', '09856432478', '23', 'Male', '97525864V', 'Walipillawa, Ganemulla, Sri Lanka', 'Guide services', 'Mint Company', 'No 45, Ganemulla rd, Ganemulla.', 'Speaking abillity for 3 languages', '2', 'Gampaha2'),
(2, 'Amalki', 'Navoday', 'amalkinawodya88@gmail.com', '098564324680', '24', 'Female', '97525464V', 'No, 67, Wihara rd, Abepussa, Sri Lanka', 'Guide services', 'Amalki guide services', 'No 66, Abepussa rd, Kurunagala.', 'Speaking abillity of English  languages', '3', 'Amalki99'),
(3, 'Kevin', 'Nugara', 'kevin@gmail.com', '64537278883', '34', 'male', '896474555362v', 'No 23/A2, , kandy road, kadawatha', 'driver', 'kevin moters and travel pvt ltd', 'N0 22/2 , Kandy road, kadawatha.', 'I never done any accidents in my carrier life', '3 years', 'kevin123'),
(4, 'Ron', 'wheesly', 'Ron@gmail.com', '645372788233', '33', 'male', '89647453623v', 'No 50, Smith road, London, England', 'Guide', 'wheesly human supplers pvt ltd', 'N0 50,Smith road, London, England', 'I can speak 3 languages including English', '3 years', 'kevin123'),
(5, 'Hermeny', 'Grenger', 'hermeny@gmail.com', '645372788233', '25', 'Female', '8964745323v', 'No 23/3/2, wadington Dc, United state of America.', 'Hotel', 'Diana Towers ', 'N0 50,Smith road, London, England', 'I can speak 2 languages including English and have a good appearance', '5 years', 'kevin123'),
(6, 'nivee', 'Riddle', 'nivee@gmail.com', '23568986422', '36', 'female', '3546576876v', 'Colombo rd, Gampaha.', 'Travel agent', 'no', 'no', '3 years exprience', '3', 'Riddle33'),
(7, 'Anula', 'Disanayake', 'anula10@gmil.com', '0987646634', '30', 'Female', '256867598v', 'No 50, Flower rd, Bandarawella.', 'Residences', 'Anula Hotel Services', 'No, 38 Bandarawela new rd, Bandarawella.', '-', '6', 'anula123'),
(8, 'Jayani', 'Kariyawasam', 'jayanikariyawasam3@gmail.com', '098754362838', '23', 'Female', '97536382374v', 'Colombo rd, Gampaha.', 'Guide services', 'no', 'no', 'muliple languages skills', '2', 'jayani97'),
(9, 'Temalka', 'Presad', 'temalkapresad@gmail.com', '9086645345352', '32', 'male', '3454657658v', 'Kadana rd, Ja Ella.', 'Tourist Guide', '', '', 'English Skills', '2', 'Temalka123');

-- --------------------------------------------------------

--
-- Table structure for table `jointable1`
--

CREATE TABLE `jointable1` (
  `id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phonenumber` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jointable1`
--

INSERT INTO `jointable1` (`id`, `firstname`, `lastname`, `email`, `phonenumber`, `password`) VALUES
(1, 'Raj', 'Rupasinghe', 'raj10@gmail.com', '098765432', 'raj12345'),
(2, 'Medoosa', 'Smith', 'medoosa45@gmail.com', '09734537388', 'med#12345'),
(3, 'Drako', 'Malfoi', 'drakomalfoi123@gmail.com', '+78543489003', 'drako123'),
(4, 'Madushan', 'Jayasinghe', 'madushan45@gmail.com', '88765378990', 'madushan555'),
(5, 'Asitha', 'lackshan', 'asithainfo15@gmail.com', '98932456678', 'asitha345'),
(6, 'Kasindi', 'Nanayakkara', 'kasindo12@gmail.com', '17337383996', 'kasindi000'),
(7, 'Imasha', 'Wanasinghe', 'imashawansinghe77@gmail.com', '0976354890', 'imasha9911'),
(8, 'Malshika', 'Hewage', 'malshika67@gmail.com', '098765345', 'Colombo10'),
(9, 'Kavindu', 'Reshan', 'kavindu67@gmail.com', '+76098765432', 'Gampaha2'),
(10, 'Geethma', 'Probodahani', 'geethma23@gmail.com', '+9756627292', 'Colombo00'),
(11, 'Madubashini', 'Amarasinghe', 'amarasinghe45@gmail.com', '87537976568', 'madu999'),
(12, 'Sanduni', 'Thasara', 'sanduni@gmail.com', '98654334', 'Colombo10'),
(13, 'kevin', 'Nugara', 'kevin@gmail.com', '0776523154', 'kevin123'),
(14, 'Binuli', 'Manulika', 'binuli@mail.com', '0985273634', 'binuli456'),
(15, 'Jayani', 'Kariyawasam', 'jayanikariyawasam3@gmail.com', '0983432793735', 'jayani97'),
(16, 'Nimasha', 'Kaavindi', 'nima@gmail.com', '+76098765432', 'nima1234');

-- --------------------------------------------------------

--
-- Table structure for table `traveldetails3`
--

CREATE TABLE `traveldetails3` (
  `id` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `contactnumber` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `NIC` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `package` varchar(50) NOT NULL,
  `members` varchar(50) NOT NULL,
  `flightnoarrival` varchar(50) NOT NULL,
  `flightnodeparture` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `traveldetails3`
--

INSERT INTO `traveldetails3` (`id`, `firstname`, `lastname`, `email`, `contactnumber`, `age`, `gender`, `country`, `NIC`, `address`, `package`, `members`, `flightnoarrival`, `flightnodeparture`, `password`) VALUES
('', 'Bawani', 'Shashikala', 'brupasinghe3@gmail.com', '0112970285', '23', 'female', 'Canada', '974153100v', 'Belgimiya', 'culture and heritage tour', '4', '12', '12', 'bawa123'),
('', 'Nafla', 'Siyabdeen', 'nafee123@gmail.com', '0112970345', '22', 'female', 'England', '9741531056v', 'London', 'Wildlife and jeep tour', '7', '16', '20', 'nafee@345'),
('', 'Ann', 'kristiyana', 'ann71@gmail.com', '+961235675946', '19', 'female', 'USA', '974153105697V', 'new city, USA', 'Discover SriLanka tour', '10', '31', '20', 'ann12345'),
('', 'John', 'kristin', 'john890@gmail.com', '+9412336759462', '30', 'male', 'Malasia', '974153105689V', 'kolarampoor', 'Adventure tour', '20', '15', '16', 'johm7890'),
('', 'Jiny', 'Jenifer', 'jiny45@gmail.com', '+98098766431', '25', 'female', 'Swissland', '4570874270V', 'Flower rd, Mish City,Swissland', 'Sri Lanka Beauty and nature tour', '12', '40', '30', 'you12345'),
('', 'Teena', 'jogiya', 'teena55@gmail.com', '+96122732683', '30', 'female', 'China', '98531359005v', 'Wuhan,China', 'Wild life Tour', '5', '30', '17', 'teena111'),
('', 'nuuna', 'frold', 'nuuna@gmail.com', '0998765', '25', 'female', 'Pilipines', '3489876v', 'new city', 'Culture & Heritage tour', '8', '90', '32', 'beets123'),
('', 'Mickey', 'veeem', 'deemanthakumara@gmail.com', '12345678', '24', 'male', 'India', '132579865v', 'new dilhi', 'Adenture tour', '2', '54', '23', 'happy12'),
('', 'mimo', 'jonathon', 'mimo456@gmail.com', '+9875322578', '46', 'male', 'Singapore', '32357890v', 'newcity', 'Adventure tour', '6', '88', '34', 'mimo'),
('', 'Andrew', 'weesliey', 'andrew4@gmail.com', '+98542477889', '43', 'male', 'British', '9842378999V', 'England', 'Discover Sri lanka tour', '3', '9', '8', 'we555'),
('', 'Tom', 'Riddle', 'tomriddle55@gmail.com', '+97557398567494', '43', 'male', 'USA', '6424689875V', 'new york, USA.', 'Culture & Heitage tour', '4', '65', '66', 'tom123'),
('', 'Drako', 'Malfoi', 'drako4@gmail.com', '08865434567', '26', 'male', 'USA', '346864267V', 'New York, USA.', 'Adventure tour', '10', '3', '5', 'drako55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact_us_tab`
--
ALTER TABLE `contact_us_tab`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `joininformation`
--
ALTER TABLE `joininformation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jointable1`
--
ALTER TABLE `jointable1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact_us_tab`
--
ALTER TABLE `contact_us_tab`
  MODIFY `ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `joininformation`
--
ALTER TABLE `joininformation`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `jointable1`
--
ALTER TABLE `jointable1`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
